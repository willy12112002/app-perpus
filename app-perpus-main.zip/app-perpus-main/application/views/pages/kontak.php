<div class="row">
    <div class="col-12">
        <h3>Kontak Saya</h3>
        <div class="box">
            <div class="box-body">
                <p>Aplikasi dibuat Oleh <a href="">Tajul Arifin S</a>. jika ada saran dan masukan, anda dapat menghubungi saya di: </p>
                <ul>
                    <li><a href="">arifintajul4@gmail.com</a></li>
                    <li>Facebook: <a target="_blank" href="https://facebook.com/arifintajul4">Tajul Arifin Sirajudin</a></li>
                    <li>Instagram: <a target="_blank" href="https://instagram.com/tajul_arifins">@tajul_arifins</a></li>
                    <li>Github: <a target="_blank" href="https://github.com/arifintajul4">arifintajul4</a></li>
                </ul> 
            </div>
        </div>
    </div>
</div>