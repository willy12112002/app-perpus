<div class="row">
    <div class="col-12">
        <h3>Tentang Aplikasi</h3>
        <div class="box">
            <div class="box-body">
                Aplikasi E-Perpus ini dibuat untuk memenuhi tugas matakuliah Rekasaya Perangkat Lunak.
            </div>
        </div>
    </div>
</div>